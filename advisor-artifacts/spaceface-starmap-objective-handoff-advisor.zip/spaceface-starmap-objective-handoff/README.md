# SpaceFace Star Map Objective Handoff fallback patch

This fallback bundle is for `coldshalamov/SpaceFace` on `master` at commit `cb00d5016ece49f4ccd82c32f15825c3c63b2f7b`.

The patch stays out of the locked graphics/asset lane. It changes only:

- `src/ui/screens/starmap.js`
- `scripts/check-starmap-objective-route.mjs`

Apply from the repository root:

```bash
git apply patches/star-map-objective-handoff.patch
node scripts/check-starmap-objective-route.mjs
```

The check is static and deterministic. It guards the player-facing contract that the Star Map reads `state.nav.waypoint`, distinguishes mission/trade objective handoff, and reuses the existing `world:requestRoute` + `ui:setCourse` path for Plot / Refresh Objective Route.
