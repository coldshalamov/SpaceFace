#!/usr/bin/env node
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/ui/screens/starmap.js', import.meta.url), 'utf8');

function includes(fragment, message) {
  assert(source.includes(fragment), message);
}

function matches(pattern, message) {
  assert(pattern.test(source), message);
}

includes('data-objective', 'Star Map sidebar must mount a dedicated objective panel.');
includes('.sm-objective', 'Star Map objective panel must have scoped styling.');
includes('.sm-objective[hidden]', 'Objective panel must hide cleanly when no waypoint exists.');
includes('_syncObjective()', 'Star Map must render objective state independently from selected sector intel.');
includes('_objective()', 'Star Map must resolve mission/trade waypoint state into display data.');
includes('_waypoint()', 'Star Map must read the canonical state.nav.waypoint source.');
includes("wp.kind === 'mission'", 'Objective copy must distinguish mission waypoints.');
includes("wp.kind === 'trade'", 'Objective copy must distinguish trade waypoints.');
includes('objective-route', 'Objective panel must expose a route action.');

matches(/if \(action === 'objective-route'\)[\s\S]*world:requestRoute[\s\S]*targetSectorId: target/, 'Objective route action must request a world route to the waypoint sector.');
matches(/if \(action === 'objective-route'\)[\s\S]*ui:setCourse[\s\S]*sectorId: target/, 'Objective route action must set course using the same navigation event path.');

matches(/wp && wp\.kind/, 'Sidebar signature must include waypoint kind so objective changes refresh.');
matches(/wp && wp\.sectorId/, 'Sidebar signature must include waypoint sector so target changes refresh.');
matches(/wp && wp\.commodityId/, 'Sidebar signature must include trade commodity so Load & Nav changes refresh.');

matches(/routeStatus\.ready[\s\S]*next jump/i, 'Rendered objective body must tell the player the next jump when a route is already plotted.');
matches(/Target is off-sector[\s\S]*plot an objective route/i, 'Rendered objective body must explain when the target needs a route.');
matches(/Target is in this sector[\s\S]*(Local Map|local fix|HUD)/i, 'Rendered objective body must explain same-sector objective handoff.');

console.log('[check-starmap-objective-route] OK: Star Map objective handoff contract present');
